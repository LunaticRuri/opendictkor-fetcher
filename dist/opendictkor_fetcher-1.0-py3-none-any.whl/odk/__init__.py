from ._opendict_fetcher import *

__all__ = ['_opendict_fetcher']
