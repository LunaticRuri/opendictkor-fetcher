# opendictkor-fetcher
